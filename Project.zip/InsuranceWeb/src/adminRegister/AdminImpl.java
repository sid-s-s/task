package adminRegister;




public interface AdminImpl {

	public void insert(Admin i);
	

}
